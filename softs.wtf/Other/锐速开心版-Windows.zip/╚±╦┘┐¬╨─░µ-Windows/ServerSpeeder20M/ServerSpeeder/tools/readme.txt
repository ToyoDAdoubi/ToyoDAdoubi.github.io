======================================
 APPEX SOFTWARE TRACING USING WPP/ETW
======================================

This directory contains the files and utility to perform software tracing
on AppEx software. The software tracing follows the Microsoft recommended
standard procedure known as WPP Tracing. More official information about
WPP/ETW tracing and utilities can be found at the following link:

  http://msdn.microsoft.com/en-us/library/ff552961(v=VS.85).aspx


--------------
 INSTALLATION
--------------

No installation is necessary for this utility. Just copy the files to a
directory convenient for you, or execute from your USB drive or any other
media that Windows recognizes.


--------------------
 START/STOP TRACING
--------------------

You must run tracelog.exe with Administrators rights. To do this in Vista
and Windows 7 and above, you need to launch a cmd window as Administrator.
Just right click the "Command Prompt" icon, click "Run as administrator".

In the Administrator Command Prompt window, cd into the location where
you store the tracelog.exe and other files.

To start tracing the engine (kernel driver), run the following:

  tracelog -start APXD -guid appexacc.ctl -flags 15 -level 4 -f <file_1>.etl

To start tracing the GUI (shown or hidden), run the following:

  tracelog -start APXG -guid appexgui.ctl -flags 15 -level 4 -f <file_2>.etl

To stop tracing:

  tracelog -stop APXD
  tracelog -stop APXG


------------------------
 COLLECTING TRACE FILES
------------------------

Please STOP TRACING BEFORE you copy the trace log files (i.e., <file_1>.etl
and <file_2>.etl as above). Otherwise, part of the trace log information may
still be in memory not flushed to the file yet.

Send us the *.etl files for analysis.
