<hr>

<div class="footer">
    Powered by <a href="https://doub.io/dbrj-2/">Directory Lister</a> © 2015-<?php echo date("Y")?>
</div>
