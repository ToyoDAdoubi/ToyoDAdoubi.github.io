<?php 
add_action('admin_menu', 'youpzt_optimize_admin');
add_action('admin_menu', 'youpzt_optimize_scripts');
function youpzt_optimize_admin(){
	add_menu_page('youpzt-optimizer', '网站优化工具','edit_private_posts','optimize_page', 'youpzt_optimize_page','dashicons-hammer',73);
	add_action( 'admin_init', 'youpzt_optimize_settings' );
}
function youpzt_optimize_scripts(){
	$optimize_get = isset($_GET['page'])? $_GET['page']:'';
	if($optimize_get=='optimize_page'){
				wp_enqueue_style('optimize-normalize',WP_YPOPTIMIZE_PLUGIN_URL.'/css/normalize.css', array(), WP_YPOPTIMIZE_VERSION);
				wp_enqueue_style('optimize-checkbox-button',WP_YPOPTIMIZE_PLUGIN_URL.'/css/checkbox-button.css', array(), WP_YPOPTIMIZE_VERSION);
				wp_enqueue_style('style',WP_YPOPTIMIZE_PLUGIN_URL.'/css/style.css', array(), WP_YPOPTIMIZE_VERSION);
				
				wp_enqueue_script( 'jquery2-1',WP_YPOPTIMIZE_PLUGIN_URL.'/js/jquery2.1.min.js', array(), WP_YPOPTIMIZE_VERSION);
				wp_enqueue_script( 'optimize-main',WP_YPOPTIMIZE_PLUGIN_URL.'/js/main.js', array('jquery2-1'), WP_YPOPTIMIZE_VERSION);
	}
}

/*settings*/
function youpzt_optimize_settings() {
	register_setting('youpzt-optimize-options-group', 'optimize_options' );
	register_setting('youpzt-optimize-settings-group', 'optimize_setting' );
}

function youpzt_optimize_page(){
?>
<div class="wrap">
<h2>网站优化工具<?php echo WP_YPOPTIMIZE_VERSION;?></h2>	
<?php	
$switch_action=isset($_GET['tab'])? $_GET['tab']:'general';
//切换
if($switch_action=='tables'){//数据库优化
	
	require_once(WP_YPOPTIMIZE_PLUGIN_DIR.'/youpzt-optimize-tables.php');
	
}elseif($switch_action=='general'||$switch_action=='switch'){//开关

	require_once(WP_YPOPTIMIZE_PLUGIN_DIR.'/youpzt-optimize-switch.php');

}elseif($switch_action=='setting'){
	require_once(WP_YPOPTIMIZE_PLUGIN_DIR.'/youpzt-optimize-setting.php');
}

?>
</div>

<?php };?>