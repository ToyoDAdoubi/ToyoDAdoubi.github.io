import os

from front_base.config import ConfigBase
import simple_http_client

current_path = os.path.dirname(os.path.abspath(__file__))
root_path = os.path.abspath(os.path.join(current_path, os.pardir, os.pardir))
data_path = os.path.abspath(os.path.join(root_path, os.pardir, os.pardir, 'data'))
module_data_path = os.path.join(data_path, 'gae_proxy')


headers = {"connection": "close"}
fqrouter = simple_http_client.request("GET", "http://127.0.0.1:2515/ping", headers=headers, timeout=0.5)
mobile = fqrouter and "PONG" in fqrouter.text
del headers, fqrouter

class Config(ConfigBase):
    def __init__(self, fn):
        super(Config, self).__init__(fn)

        # proxy
        self.set_var("listen_ip", "127.0.0.1")
        self.set_var("listen_port", 8087)

        # auto range
        self.set_var("AUTORANGE_THREADS", 10)
        self.set_var("AUTORANGE_MAXSIZE", 512 * 1024)
        if mobile:
            self.set_var("AUTORANGE_MAXBUFFERSIZE", 10 * 1024 * 1024 / 8)
        else:
            self.set_var("AUTORANGE_MAXBUFFERSIZE", 20 * 1024 * 1024)
        self.set_var("JS_MAXSIZE", 0)

        # gae
        self.set_var("GAE_PASSWORD", "")
        self.set_var("GAE_VALIDATE", 0)

        # host rules
        self.set_var("hosts_direct", [
            "play.google.com",
            "scholar.google.com",
            "scholar.google.com.hk",
            "appengine.google.com"
        ])
        self.set_var("hosts_direct_endswith", [
            ".appspot.com",
        ])

        self.set_var("hosts_gae", [
            "accounts.google.com",
            "mail.google.com"
        ])

        self.set_var("hosts_gae_endswith", [
        ])

        # sites using br
        self.set_var("BR_SITES", [
            "webcache.googleusercontent.com",
            "www.google.com",
            "www.google.com.hk",
            "www.google.com.cn",
            "fonts.googleapis.com"
        ])

        self.set_var("BR_SITES_ENDSWITH", [
            ".youtube.com",
            ".facebook.com",
            ".googlevideo.com"
        ])

        # some unsupport request like url length > 2048, will go Direct
        self.set_var("google_endswith", [
            ".youtube.com",
            ".googleapis.com",
            ".google.com",
            ".googleusercontent.com",
            ".ytimg.com",
            ".doubleclick.net",
            ".google-analytics.com",
            ".googlegroups.com",
            ".googlesource.com",
            ".gstatic.com",
            ".appspot.com",
            ".gvt1.com",
            ".android.com",
            ".ggpht.com",
            ".googleadservices.com",
            ".googlesyndication.com",
            ".2mdn.net"
        ])

        # front
        self.set_var("front_continue_fail_num", 10)
        self.set_var("front_continue_fail_block", 0)

        # http_dispatcher
        self.set_var("dispather_min_idle_workers", 5)
        self.set_var("dispather_work_min_idle_time", 0)
        self.set_var("dispather_work_max_score", 1000)
        self.set_var("dispather_min_workers", 30)
        self.set_var("dispather_max_workers", 90)
        self.set_var("dispather_max_idle_workers", 30)

        # http 1 worker
        self.set_var("http1_first_ping_wait", 5)
        self.set_var("http1_idle_time", 200)
        self.set_var("http1_ping_interval", 0)

        # http 2 worker
        self.set_var("http2_max_concurrent", 20)
        self.set_var("http2_target_concurrent", 1)
        self.set_var("http2_max_timeout_tasks", 1)
        self.set_var("http2_timeout_active", 0)
        self.set_var("http2_ping_min_interval", 30)

        # connect_manager
        self.set_var("https_max_connect_thread", 10)
        self.set_var("ssl_first_use_timeout", 5)
        self.set_var("connection_pool_min", 1)
        self.set_var("https_connection_pool_max", 10)
        self.set_var("https_new_connect_num", 3)
        self.set_var("https_keep_alive", 15)

        # check_ip
        self.set_var("check_ip_host", "xxnet-1.appspot.com")
        self.set_var("check_ip_accept_status", [200, 503])
        self.set_var("check_ip_content", "GoAgent")

        # host_manager
        self.set_var("GAE_APPIDS", [])

        # connect_creator
        self.set_var("check_pkp", [
b'''\
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnCoEd1zYUJE6BqOC4NhQ
SLyJP/EZcBqIRn7gj8Xxic4h7lr+YQ23MkSJoHQLU09VpM6CYpXu61lfxuEFgBLE
XpQ/vFtIOPRT9yTm+5HpFcTP9FMN9Er8n1Tefb6ga2+HwNBQHygwA0DaCHNRbH//
OjynNwaOvUsRBOt9JN7m+fwxcfuU1WDzLkqvQtLL6sRqGrLMU90VS4sfyBlhH82d
qD5jK4Q1aWWEyBnFRiL4U5W+44BKEMYq7LqXIBHHOZkQBKDwYXqVJYxOUnXitu0I
yhT8ziJqs07PRgOXlwN+wLHee69FM8+6PnG33vQlJcINNYmdnfsOEXmJHjfFr45y
aQIDAQAB
-----END PUBLIC KEY-----
''',
# https://pki.goog/gsr2/GIAG3.crt
# https://pki.goog/gsr2/GTSGIAG3.crt
b'''\
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAylJL6h7/ziRrqNpyGGjV
Vl0OSFotNQl2Ws+kyByxqf5TifutNP+IW5+75+gAAdw1c3UDrbOxuaR9KyZ5zhVA
Cu9RuJ8yjHxwhlJLFv5qJ2vmNnpiUNjfmonMCSnrTykUiIALjzgegGoYfB29lzt4
fUVJNk9BzaLgdlc8aDF5ZMlu11EeZsOiZCx5wOdlw1aEU1pDbcuaAiDS7xpp0bCd
c6LgKmBlUDHP+7MvvxGIQC61SRAPCm7cl/q/LJ8FOQtYVK8GlujFjgEWvKgaTUHF
k5GiHqGL8v7BiCRJo0dLxRMB3adXEmliK+v+IO9p+zql8H4p7u2WFvexH6DkkCXg
MwIDAQAB
-----END PUBLIC KEY-----
''',
# https://pki.goog/gsr4/GIAG3ECC.crt
b'''\
-----BEGIN PUBLIC KEY-----
MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEG4ANKJrwlpAPXThRcA3Z4XbkwQvW
hj5J/kicXpbBQclS4uyuQ5iSOGKcuCRt8ralqREJXuRsnLZo0sIT680+VQ==
-----END PUBLIC KEY-----
'''
        ])
        self.set_var("check_commonname", "Google")
        self.set_var("min_intermediate_CA", 2)
        self.set_var("support_http2", 1)

        # ip_manager
        self.set_var("max_scan_ip_thread_num", 10)
        self.set_var("max_good_ip_num", 100)
        self.set_var("target_handshake_time", 500)

        # ip source
        self.set_var("use_ipv6", "force_ipv6") #force_ipv4/force_ipv6/auto
        self.set_var("ipv6_scan_ratio", 90) # 0 - 100

        self.load()

    def load(self):
        super(Config, self).load()

        need_save = 0
        if not os.path.isfile(self.config_path):
            for fn in [
                os.path.join(module_data_path, "config.ini"),
                os.path.join(module_data_path, "manual.ini")
            ]:
                need_save += self.load_old_config(fn)

        self.HOSTS_GAE = tuple(self.hosts_gae)
        self.HOSTS_DIRECT = tuple(self.hosts_direct)
        self.HOSTS_GAE_ENDSWITH = tuple(self.hosts_gae_endswith)
        self.HOSTS_DIRECT_ENDSWITH = tuple(self.hosts_direct_endswith)
        self.GOOGLE_ENDSWITH = tuple(self.google_endswith)

        self.br_sites = tuple(self.BR_SITES)
        self.br_endswith = tuple(self.BR_SITES_ENDSWITH)

        if need_save:
            self.save()

    def load_old_config(self, fn):
        if not os.path.isfile(fn):
            return 0

        need_save = 0
        with open(fn, "r") as fd:
            for line in fd.readlines():
                if line.startswith("appid"):
                    try:
                        appid_str = line.split("=")[1]
                        appids = []
                        for appid in appid_str.split("|"):
                            appid = appid.strip()
                            appids.append(appid)
                        self.GAE_APPIDS = appids
                        need_save += 1
                    except Exception as e:
                        pass
                elif line.startswith("password"):
                    password = line.split("=")[1].strip()
                    self.GAE_PASSWORD = password
                    need_save += 1

        return need_save


config_path = os.path.join(module_data_path, "config.json")
config = Config(config_path)
directconfig = Config(config_path)
directconfig.dispather_min_idle_workers = 3
directconfig.dispather_work_min_idle_time = 0
directconfig.dispather_work_max_score = 1000
directconfig.dispather_min_workers = 5
directconfig.dispather_max_workers = 8
directconfig.dispather_max_idle_workers = 5
