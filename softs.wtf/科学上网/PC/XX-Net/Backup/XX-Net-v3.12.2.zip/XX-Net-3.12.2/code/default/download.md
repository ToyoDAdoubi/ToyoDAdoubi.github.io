
## 下载(Download)：
稳定版(Stable)：  
https://codeload.github.com/XX-net/XX-Net/zip/3.11.15


测试版(Test)：  
https://codeload.github.com/XX-net/XX-Net/zip/3.12.1


Android:  
集成fqrouter和XX-Net，推荐：  
https://github.com/XndroidDev/Xndroid/releases

单纯XX-Net，不能自动设置代理：    
https://github.com/XX-net/xxnet-android/releases/download/3.6.3/XX-Net-3.6.3-debug.apk
