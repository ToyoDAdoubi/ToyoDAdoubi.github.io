/******************************************************************************\
 *  This sample is supplied as is with no implied warranty.  
 *  It is designed to assist you in using the Cisco AnyConnect VPN API. 
 *  It is assumed that you will build a production application and 
 *  refer to this sample as a reference only.
 \*****************************************************************************/

#include "CLIClientImpl.h"


void usage()
{
    printf("usage: example [connect <host> <username> <pswd>, disconnect, stats, state, hosts, defaultHost, showGroups <host>]\n");
}

int
main(int argc, char **argv)
{
    CLIClientImpl impl;

    if (argc == 1)
    {
        usage();
    }
    else if (argc >= 2)
    {
        // get tag connect, disconnect, stats, state
        std::string arg = argv[1];

        if (arg == "hosts")
        {
            impl.printHostList();
        }
        else if (arg == "defaultHost")
        {
            impl.printDefaultHost();
        }
        else
        {
            if (!impl.attach())
            {
                printf("Failed to contact vpn service, check log\n");
                exit(1);
            }

            if (arg == "connect"  &&  argc >= 5)
            {
                std::string host = argv[2];
                std::string user = argv[3];
                std::string pswd = argv[4];
                std::string group = "";

                if (argc == 6)
                {
                    group = argv[5];
                }
                impl.connect(host, user, pswd, group);
            }
            else if (arg == "disconnect")
            {
                impl.disconnect();
            }
            else if (arg == "stats")
            {
                impl.getStats();
            }
            else if (arg == "state")
            {
                printf("%s\n", impl.isConnected() ? "Tunnel up" :"Tunnel down");
            }
            else if (arg == "showGroups"  &&  argc == 3)
            {
                std::string host = argv[2];

                // The method connect will result in the UserPromptCB method
                // being called.  In this case, that method will detect this
                // request and print the Group list.
                //
                impl.showGroups(host);
            }
            else
            {
                usage();
            }

            impl.detach();
        }
    }
    else
    {
        usage();
    }

}
