/**************************************************************************
*       Copyright � 2008, Cisco Systems, All Rights Reserved
***************************************************************************
*
*  File:    PreferenceInfo.h
*  Date:    07/2008
*
***************************************************************************
*
*   Preference Info class declaration for the Client API.
*
***************************************************************************/

#ifndef _PREFERENCEINFO_
#define _PREFERENCEINFO_


/**
* Class representing a collection of preferences that are grouped together.
* Provides the ability to retrieve an ordered list of preferences, as well as
* as a generic heading that describes this grouping of preferences.
*/

#include "PreferenceInfoBase.h"


class VPN_VPNAPI PreferenceInfo : public PreferenceInfoBase
{

    public:

        /**
         * This method returns the count of any available Preference objects
         * (both parent and child).
         */
        unsigned int countPreferences() const;


        /**
        * If there exists a Preference with the passed ::PreferenceId, returns
        * a pointer to that Preference object in the passed rpPreference pointer.
        * Returns false if no such preference could be found.
        */
        bool getPreference(const PreferenceId& preferenceId, 
                           OUT Preference*& rpPreference) const;


        /**
        * Returns a vector of preferences.  The order is significant, and 
        * represents the visual order with which prompts should be displayed.
        * To access the child preferences of the returned preferences use 
        * Preference::getChildren()
        */
        const std::vector<Preference*>& getListPreferences() const;

        
        /**
        * Returns a string that describes the contents of this PreferenceInfo.
        * User Interfaces should display this string at the top of the dialog
        * or screen used to display preference controls/widgets.
        */    
        const tstring getPreferenceHeading() const;


        PreferenceInfo();
};

#endif // _PREFERENCEINFO_
