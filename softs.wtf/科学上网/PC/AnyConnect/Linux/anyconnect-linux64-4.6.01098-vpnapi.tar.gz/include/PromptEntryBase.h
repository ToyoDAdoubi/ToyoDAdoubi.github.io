/**************************************************************************
*       Copyright (c) 2008, Cisco Systems, All Rights Reserved
***************************************************************************
*
*  File:    PromptEntryBase.h
*  Date:    01/2008
*
***************************************************************************
*
*   Prompt Entry base class implementation for the Client API.
*
***************************************************************************/

#ifndef _PROMPTENTRYBASE_
#define _PROMPTENTRYBASE_


#include "api.h"
#include <list>


#define PROMPT_ENTRY_VALUE_TRUE  _T("true")
#define PROMPT_ENTRY_VALUE_FALSE  _T("false")

class VPN_VPNAPI PromptEntryBase
{
    public:

        bool setValue(tstring value);

        const tstring &getPromptName() const;

        const tstring &getPromptLabel() const;

        bool isEnabled() const;

        void setEnabled(bool bIsEnabled);

        bool isVisible() const;

        void setVisible(bool bIsVisible);

        // if this is a PromptEntry that has a list of values
        // (e.g. combo box style) the default will be to mark it as a group
        // combo.  This method allows the group designation to be set directly.
        //
        void setEntryGroup(bool bIsEntryGroup);


        PromptEntryBase(tstring PromptName,
                        tstring PromptLabel,
                        PromptType promptType = Prompt_Input,
                        tstring DefaultValue = EmptyString,
                        ApiStringMap LabelValues = EmptyLabelValues);


        void setPromptLabel(tstring label);

        // In cases of prompt types with options (checkbox, combobox),
        // this will return the translated label (of the option).
        const tstring &getValue() const;

        // this function returns the internal representation of the value
        const tstring &getTrueValue() const;

        const std::list<tstring> &getValueOptions() const;

        bool isEntryGroup() const;

        bool isReadOnly() const;

        PromptType getPromptType() const;

        size_t GetGroupAttributesCount();


        ~PromptEntryBase();

        static const tstring EmptyString;

        static const std::list<tstring> EmptyList;

        static const ApiStringMap EmptyLabelValues;

        PromptEntryBase& operator=(const PromptEntryBase& assignmentOperator);

        PromptEntryBase(const PromptEntryBase& existingEntry);


    private:

        tstring ms_PromptName;

        tstring ms_PromptLabel;

        PromptType me_PromptType;

        tstring ms_Value;

        ApiStringMap msm_LabelValueMap;

        std::list<tstring> mls_ValueOptions;

        bool mb_IsEntryGroup;

        bool mb_Enabled;

        bool mb_Visible;

    public:
        
        class GroupAttributes
        {
        public:
            GroupAttributes() :
              CredRequired(true),
              UsesSDIAuth(false),
              UsernameEditable(true),
              Username(),
              SecondaryUsernameEditable(true),
              SecondaryUsername(),
              UsesSecondaryAuth(false) {}

            bool CredRequired;
            bool UsesSDIAuth;
            bool UsernameEditable;
            tstring Username;
            bool SecondaryUsernameEditable;
            tstring SecondaryUsername;
            bool UsesSecondaryAuth;
        };

        class SingleAttributes
        {
        public:
            SingleAttributes() :
              SecondaryAuthEntry(false),
              SSOTimeoutSeconds(0) {}

            bool SecondaryAuthEntry;
            tstring SSOURL;
            tstring SSOFinalURL;
            tstring SSOTokenCookieName;
            tstring SSOErrorCookieName;
            unsigned int SSOTimeoutSeconds;
        };

        typedef std::map<tstring, GroupAttributes> GroupAttributeMap;

        const GroupAttributes& getGroupAttributes(const tstring& group) const;
        void setGroupAttributeMap(const GroupAttributeMap& groupAttributeMap);

        const SingleAttributes& getSingleAttributes() const;
        void setSingleAttributes(const SingleAttributes& singleAttributes);

    private:

        void copyGroupAttributeMap (const GroupAttributeMap &source,
                                    GroupAttributeMap &destination);
        static const GroupAttributes DefaultGroupAttributes;
        GroupAttributeMap m_GroupAttributeMap;

        SingleAttributes m_SingleAttributes;
};


#endif // _PROMPTENTRYBASE_
