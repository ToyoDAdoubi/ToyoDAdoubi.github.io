/**************************************************************************
*       Copyright (c) 2017, Cisco Systems, All Rights Reserved
***************************************************************************
*
*  File:    pkgint.js
*
***************************************************************************
*
* Windows init file for AnyConnect Secure Mobility Client WebLaunch.
*
***************************************************************************/

var supportedCpu = ["X86", "AMD64"];
var packagePlatform = "Windows 7 SP1 or newer";
var packageConnectImg = new Image(159, 46);
packageConnectImg.src = "img/windows-trayicon.gif";

var packageConnectMsg;
   
function loadPackage ()
{    
    packageConnectMsg = 'The connection can be controlled from the tray icon, circled in the image below:<br><br><div align="center"><img src="' 
                        + packageConnectImg.src + '" width ="' + packageConnectImg.width + '" height="' + packageConnectImg.height + '"><br>';
   
    if (IsIntelMacOsX || IsLinux)
    {
        // Magic state -60 == go to the next installed package
        Start(-60);
    }
    else
    {
        // Magic state 1 == begin full windows detection sequence
        Start(0);
    }
}
var packageInstaller = "anyconnect-win-4.6.01098-core-vpn-webdeploy-k9.exe";
var packageVersion = "4,6,01098";
var packageISEPostureInstaller = "anyconnect-win-4.6.01098-iseposture-webdeploy-k9.msi"; 
var packageAnyConnectNetworkSetupAssistant = "anyconnect-ise-network-assistant-win-4.6.01098.exe"; 
