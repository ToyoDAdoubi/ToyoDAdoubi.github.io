/* global us */

/**************************************************************************
*       Copyright (c) 2017, Cisco Systems, All Rights Reserved
***************************************************************************
*
*  File:    main.js
*
***************************************************************************
*
* Main Javascript for AnyConnect Secure Mobility Client WebLaunch.
*
***************************************************************************/
var iStatus = 0;
var aszMessage = new Array( new Array( 70 ) );
var timeWaitStart;

//---------- Platform Checks  ----------
var agt = navigator.userAgent.toLowerCase();
var IsLinux64 = ( ( agt.indexOf("linux") !== -1 ) && ( agt.indexOf("x86_64") !== -1) );
var IsLinux = ( ( agt.indexOf("linux") !== -1 ) && ( agt.indexOf("x86_64") === -1) );
var IsPowerPcMacOsX = ( ( agt.indexOf("ppc mac os x") !== -1) ||
                        ( agt.indexOf("mac_powerpc") !== -1) );
var IsIntelMacOsX = ( ( agt.indexOf("intel mac os x") !== -1) );
var IsMac = (IsIntelMacOsX || IsPowerPcMacOsX);
var IsWinNT = ( (agt.indexOf( "windows nt") !== -1) );
//---------- Browser Checks  ----------
var IsIE = ( (( agt.indexOf( "msie" ) !== -1 ) || ( agt.indexOf( "trident" ) !== -1 )) && ( agt.indexOf( "opera" ) === -1 ) );
var IsEdge = (navigator.appVersion.indexOf('Edge') > -1); // IE Edge
var IsIEorEDGE = (IsIE || IsEdge);

var IsChrome = window.chrome !== null && window.navigator.vendor === "Google Inc.";

var IsIEandNot2k = ( IsIE && ( agt.indexOf( "windows nt 5.0") === -1 )
                     && !IsPowerPcMacOsX && !IsIntelMacOsX );
var IsIE64 = ( ( agt.indexOf( "win64" ) !== -1 ) && ( agt.indexOf( "x64" ) !== -1 ) );

//var isFireFox32bit = ((agt.indexOf("firefox" ) !== -1)  && (window.navigator.platform === "Win32"));
//var isFireFoxESR = ( (agt.indexOf("firefox" ) !== -1)  && (us.indexOf("esr") !== -1));


//----------- NPAPI based plugin checks -----------
function  isJAVAorActiveXSupported () {
    
    //Since Edge does not support any NPAPI based plugins 
    //Do not add the option to provide weblaunch on this browser
    //Caveat:  Firefox still supports JAVA in there ESR flavor of browsers 
    //         so we do not currently restrict firefox.
    return !IsEdge && !IsChrome;
}


//---------- Global Defs  ----------
var bLoop = false;
var isAppletRunning = false;
var appletCookieName = "vpnJavaApplet";
var appletCookieValue = "61561";
var language = 0;
var clientName = "Cisco AnyConnect Secure Mobility Client";

// 0 = initial value
// 1 = ActiveX/Java has started to run
// 2 = Downloader launched
// 3 = Downloader terminated and reported success
// Any new status codes used just between the JavaScript and ActiveX/Java
// must be positive values defined in both the ActiveX/Java and Javascript.
//
var STATUS_INITIAL_VALUE         = 0;
var STATUS_STARTED               = 1;
var STATUS_DL_IN_PROGRESS        = 2;
var STATUS_DL_SUCCESS            = 3;

var str_STATUS_INITIAL_VALUE     = "0";
var str_STATUS_STARTED           = "1";
var str_STATUS_DL_IN_PROGRESS    = "2";
var str_STATUS_DL_SUCCESS        = "3";

// All negative values are a 1 to 1 match to downloader exit codes where only
// the sign of the value has been changed.  For example, if the downloader exits
// with a value of 1, the javascript will receive a value of -1. This is because
// the ActiveX and Java negate the downloader exit codes and pass them through
// (accept for SUCCESS and TRY_NEW).  This allows for new downloader exit code
// handling to be added to the Javascript without having to change the ActiveX
// or Java, which is a real pain to do.  The downloader exit codes are defined
// in GlobalDefs.h.
//
var STATUS_DL_FAILURE                     				= -1;
var STATUS_DL_APP_TRY_NEW                 				= -2; // not used, eaten by ActiveX/Java, here for completeness
var STATUS_DL_CONNECTION_FAILURE          				= -3;
var STATUS_DL_REBOOT_REQUIRED             				= -4;
var STATUS_DL_WEBLAUNCH_RESTRICTED        				= -6; // exit code 5 is taken by downloader lacking privileges
var STATUS_DL_ALLOW_UNTRUSTED_CERT_RETRY  				= -7;
var STATUS_DL_GUI_LAUNCH_FAILED          		 		= -8;
var STATUS_DL_NON_PRIVELEGED_SECOND_INSTANCE     		= -9;
var STATUS_DL_AC_CORE_UPDATES_FROM_ISE_OVER_VPN_TUNNEL	= -10;
var STATUS_DL_KEEP_ME_SAFE_UNTRUSTED_CERT               = -11;
var STATUS_DL_VERIFY_CERT_PIN_CHECK_FAILED              = -15; // exit codes 12, 13, 14 taken.

var str_STATUS_DL_FAILURE                                  = "-1";
var str_STATUS_DL_APP_TRY_NEW                              = "-2"; // not used, eaten by ActiveX/Java, here for completeness
var str_STATUS_DL_CONNECTION_FAILURE                       = "-3";
var str_STATUS_DL_REBOOT_REQUIRED                          = "-4";
var str_STATUS_DL_WEBLAUNCH_RESTRICTED                     = "-6"; // exit code 5 is taken by downloader lacking privileges
var str_STATUS_DL_ALLOW_UNTRUSTED_CERT_RETRY               = "-7";
var str_STATUS_DL_GUI_LAUNCH_FAILED                        = "-8";
var str_STATUS_DL_NON_PRIVELEGED_SECOND_INSTANCE           = "-9";
var str_STATUS_DL_AC_CORE_UPDATES_FROM_ISE_OVER_VPN_TUNNEL = "-10";
var str_STATUS_DL_KEEP_ME_SAFE_UNTRUSTED_CERT              = "-11";
var str_STATUS_DL_VERIFY_CERT_PIN_CHECK_FAILED             = "-15"; // exit codes 12, 13, 14 taken

// Number of times to wait in prompt states before attempting next 
// installation mechanism.  State is evaluated every 500 milliseconds, 
// so divide by two to get the number of seconds to delay.  Default is 30 seconds.
var timeout_count = 60;

var stDownloadURL = GetDownloadURL();
var stCookie = GetCookie("webvpn");
var stCfgCookie = GetCookie("webvpnc");
var stAggAuth = GetCookie("webvpnaac");
var stConfigurationURI = "";

var stLaunchType = GetCookie("launchtype");

function hasClass(el, className) {
  if (el.classList)
    return el.classList.contains(className);
  else
    return !!el.className.match(new RegExp('(\\s|^)' + className + '(\\s|$)'));
}

function addClass(el, className) {
  if (el.classList)
    el.classList.add(className);
  else if (!hasClass(el, className)) el.className += " " + className;
}

function removeClass(el, className) {
  if (el.classList)
    el.classList.remove(className);
  else if (hasClass(el, className)) {
    var reg = new RegExp('(\\s|^)' + className + '(\\s|$)');
    el.className=el.className.replace(reg, ' ');
  }
}

/**
 * @return {string}
 */
function EncodeHTML(str)
{
    var div = document.createElement('div');
    div.appendChild(document.createTextNode(str));
    return div.innerHTML;
}

/**
 * @return {string}
 */
function GetDownloadURL()
{
    var url = window.location.protocol + '//' + window.location.hostname;
    var port = window.location.port;
    if (port)
    {
        url += ':' + port;
    }
    url += window.location.pathname;
    return decodeURI(url);
}

function skipToManualInstall() {
    iStatus = -70;
    Launch();
}

//0 Wait for start
//1 Let's start
//10 Download OCX
//11 OCX Security
//12 Check OCX status + setup OCX
//13 OCX started. OCX success?
//14 OCX launched downloader 
//15 OCX failed
//16 Second-stage ActiveX notification and timeout
//20 Trying to launch Java
//22 Java launch failed
//41 Launch Java (VM Sun/Oracle) success?
//42 Launching install from Java (VM Sun/Oracle)
//43 Install launched from Java (VM Sun/Oracle).
//44 Java (VM Sun/Oracle) failed
//-60 Complete failure, go to next package
//-70 Manual Download
//-71 Auto Provisioning
//-80 Connection failed
//-81 Reboot required
//-90 Weblaunched attempted when restricted
//-91 User wants to disable the preference to block unsafe connections and must now retry the connection
//-92 Updates completed but failed to launch AnyConnect GUI
//-93 Prevent downloader when AnyConnect is launched from web portal and stand alone client simultaneously
//-94 Prevent AnyConnect core updates from ISE when VPN tunnel is already established.
//-95 User selected to block unsafe connection (keep me safe) and must retry to change the preference
//-96 Certificate Pin Check Failed
//-100 Connection Established (VPN) / Installation Completed (ISEPosture)

function Start( iStatusf )
{
    iStatus = iStatusf;
    bLoop = true;
    language = 0;

    Launch();
}

function CvcLogout ()
{
    if (stCfgCookie !== "cookie")
    {
        // goto <prefix>/logout
        var new_path = window.location.href;
        var pos = new_path.indexOf( "/stc/" ) + 5;
        if ( pos !== 4 )
        {
                new_path = new_path.substring(0,pos) + "logout";
                window.location.href = new_path;
        }
    }
    else
    {
        // Backwards compat for ASA/3K URLs     
        window.location.replace("/webvpn_logout");
    }
}

// note: side effect! transitions to failure states if ocx doesn't load
function GetOcx ()
{
    var ocx = document.frames[ "idiFrameMain" ].document.all.idOCX;
    
    if (typeof ocx.status == 'undefined')
    {
         iStatus = 15;
    }

    return ocx;
}

function ToggleHelpButtonEnable(helpButtonState)
{
    if (helpButtonState)
    {
        var helpBtn = GetElement("helpButton");
        if(helpBtn)
        {
            helpBtn.style.visibility = "hidden";
        }
    }
}

function ToggleDownloadButtonEnable(downloadButtonState)
{
    var manualInstallBtn = GetElement("manualInstallButton");
    if(manualInstallBtn)
    {
        manualInstallBtn.disabled = downloadButtonState;
    }
}

function GetElement (idTag)
{
    return document.getElementById(idTag);
}

//
// Set the invoked-by code to indicate which app started the downloader.
//   One of:
//      "ie" - Internet Explorer
//      "ff" - Firefox
//      "sa" - Safari
//      "cl" - stand-alone client
//      "xx" - unknown 
//
function GetInvokedByCode()
{
    var InvokedByCode = "xx";
    if ((agt.indexOf("msie") !== -1) || ( agt.indexOf( "trident" ) !== -1 ))
    {
        InvokedByCode = "ie";
    } else {
        if (agt.indexOf("firefox") !== -1)
        {
            InvokedByCode = "ff";
        } else {
            if (agt.indexOf("safari") !== -1)
            {
                InvokedByCode = "sa";
            }
        }
    }
    return InvokedByCode;
}

function updateMessage()
{
	document.getElementById( "idDivMessage" ).innerHTML = aszMessage[language][ Math.abs( iStatus ) ];
}

function DeleteCookie (name) 
{
	/*All cookies from the applet(s) are set with path=/
	 * if for some reason we need to change the path, 
	 * make sure it is changed in this function as well
	 * or, set it as a parameter */
	if (GetCookie(name)) 
	{
		document.cookie =   name + "=" +
                                    "; path=/" + 
                                    "" +
                                    "; expires=Thu, 01-Jan-70 00:00:01 GMT";
	}
}


function showUntrustedCertRetry()
{
    setAlert(1,"Untrusted VPN Servers Allowed");
    GetElement("idDivMessage").innerHTML += '<br><br>Please <a href="javascript:document.location.reload()">retry the connection</a> if you wish to continue.';
}

/**
 * @return {string}
 * @return {string}
 */
function GetCookie(name) {
	var dc = document.cookie;
	var prefix = name + "=";
	var begin = dc.indexOf("; " + prefix);
	if (begin === -1) {
		begin = dc.indexOf(prefix);
		if (begin !== 0) return "";
	} else {
		begin += 2;
	}
	var end = document.cookie.indexOf(";", begin);
	if (end === -1) {
		end = dc.length;
	}

    var value=dc.substring(begin + prefix.length, end);
    // strip all double quotes so we do not break string concatenation
    value = value.replace(/\"/g, "");
	return value;
}

function Launch()
{
    var ocx;
    var timeWaitNow;

	updateMessage();
	switch ( iStatus )
	{
	case 0:
            bLoop = false;
            break;
	case 1:
            if ( IsWinNT )
            {
                if ( IsIE )
                {
                       iStatus = 10;
                } else {
                        iStatus = 20;
                }
            }
            else
            {
                // not Windows NT based OS; skip ActiveX and try Java
                iStatus = 20;
	    }
		break;
	case 10:
            //setAlert(1,"Using ActiveX for Installation");
            if ( IsIE64 )
            {
                    document.all.idiFrameMain.src = 'binaries/ocx64.htm';
            } else {
                    document.all.idiFrameMain.src = 'binaries/ocx.htm';
            }
            iStatus = 11;
        
        break;
	case 11:
		break;
	case 12:
            ocx = GetOcx();
            if ( typeof ocx.status == 'undefined' )
                break;
            try 
            {
                var targetCpu = ocx.targetCpu;
                var bTargetCpuSupported = false;

                for (var i=0; i<supportedCpu.length; i++) 
                {
                    if (targetCpu == supportedCpu[i])
                    {
                        bTargetCpuSupported = true;
                            break;
                    }
                }

                if (!bTargetCpuSupported)
                {
                    iStatus = -60;
                    break;
                }

                ocx.cookie = stCookie;
                ocx.cfgcookie = stCfgCookie;
                ocx.pkgver = packageVersion;
                ocx.aggauth = stAggAuth;
                ocx.configurationuri = stConfigurationURI;
                ocx.launchtype = stLaunchType;

            // invokedByCode is always "ie" for ActiveX so it is hard-coded in AxControlCtrl.cpp
            // MUST set url last as this triggers ActiveX to do the download
            ocx.url = encodeURI(stDownloadURL);

                iStatus = 13;
            }
            catch (err)
            {
                iStatus = 15;
            }
            break;
	case 13:
            ocx = GetOcx();
            if ( typeof ocx.status == 'undefined' )
                break;
            else if ( ocx.status == STATUS_DL_FAILURE )
                iStatus = 15;
            else if ( ocx.status == STATUS_DL_IN_PROGRESS )
                iStatus = 14;
            else if (ocx.status == STATUS_DL_SUCCESS)
                iStatus = -100;
            else if (ocx.status == STATUS_DL_CONNECTION_FAILURE)
                iStatus = -80;
            else if (ocx.status == STATUS_DL_REBOOT_REQUIRED)
                iStatus = -81;
            else if (ocx.status == STATUS_DL_WEBLAUNCH_RESTRICTED)
                iStatus = -90;
            else if (ocx.status == STATUS_DL_ALLOW_UNTRUSTED_CERT_RETRY)
                iStatus = -91;
            else if (ocx.status == STATUS_DL_GUI_LAUNCH_FAILED)
                iStatus = -92;
            else if (ocx.status == STATUS_DL_NON_PRIVELEGED_SECOND_INSTANCE)
                 iStatus = -93;
            else if (ocx.status == STATUS_DL_AC_CORE_UPDATES_FROM_ISE_OVER_VPN_TUNNEL)
		iStatus = -94;
            else if (ocx.status == STATUS_DL_KEEP_ME_SAFE_UNTRUSTED_CERT)
                iStatus = -95;
            else if (ocx.status == STATUS_DL_VERIFY_CERT_PIN_CHECK_FAILED)
                iStatus = -96;
            break;
    case 14:
            ocx = GetOcx();
            if ( typeof ocx == 'undefined' || typeof ocx.status == 'undefined')
                break;
        
            else if (ocx.status == STATUS_DL_FAILURE)
                iStatus = 15;
            else if (ocx.status == STATUS_DL_SUCCESS)
                iStatus = -100;
            else if (ocx.status == STATUS_DL_CONNECTION_FAILURE)
                iStatus = -80;
            else if (ocx.status == STATUS_DL_REBOOT_REQUIRED)
                iStatus = -81;
            else if (ocx.status == STATUS_DL_WEBLAUNCH_RESTRICTED)
                iStatus = -90;
            else if (ocx.status == STATUS_DL_ALLOW_UNTRUSTED_CERT_RETRY)
                iStatus = -91;
            else if (ocx.status == STATUS_DL_GUI_LAUNCH_FAILED)
                iStatus = -92;
            else if (ocx.status == STATUS_DL_AC_CORE_UPDATES_FROM_ISE_OVER_VPN_TUNNEL)
                iStatus = -94;
            else if (ocx.status == STATUS_DL_KEEP_ME_SAFE_UNTRUSTED_CERT)
                iStatus = -95;
            else if (ocx.status == STATUS_DL_VERIFY_CERT_PIN_CHECK_FAILED)
                iStatus = -96;
            break;
	case 15:
            if ( IsIEandNot2k )
            {
                iStatus = 16;
            }		
            else
            {       
                iStatus = 20;
            }
            break;
	case 16:
            // Remain in this state and display the ActiveX prompt
            // and countdown until it expires
            var timeout_message = "<br>Continuing in <b>" + Math.ceil(timeout_count / 2) + '</b> seconds [<a href="javascript:Start(20);">skip</a>].';

            document.getElementById( "idDivMessage" ).innerHTML += timeout_message;

            timeout_count--;
            if (0 == timeout_count)
            {
                    iStatus = 20;
            }
            break;		
	case 20:
        //Attempting to use Java for Installation
		ToggleDownloadButtonEnable(false);
		if ( ! navigator.javaEnabled() )
			iStatus = 22;
		else
		{

			var stContent;
			ToggleDownloadButtonEnable(true);
			//As a security, delete the cookie before starting the applet
			DeleteCookie (appletCookieName);
			if ( IsIE )
			{
				stContent = '<html><body><applet id="idJavaSun" name="idJavaSun" width="0" height="0" code="VPNJava.VPNJava" archive="binaries/VPNJava.jar"><param name="url" value="' + EncodeHTML(encodeURI(stDownloadURL)) + '"><param name="cookie" value="' + stCookie + '"><param name="cfgcookie" value="' + stCfgCookie + '"><param name="invokedByCode" value="' + GetInvokedByCode() +'"><param name="pkgver" value="' + packageVersion + '"><param name="aggauth" value="' + stAggAuth + '"><param name="configurationuri" value="' + stConfigurationURI + '"><param name="launchtype" value="' + stLaunchType + '"></applet></body></html>';
				document.frames[ "idiFrameMain" ].document.write( stContent );
			}
			else
			{
                stContent = '<applet id="idJavaSun" name="idJavaSun" width="0" height="0" code="VPNJava.VPNJava" archive="binaries/VPNJava.jar"><param name="url" value="' + EncodeHTML(encodeURI(stDownloadURL)) + '"><param name="cookie" value="' + stCookie + '"><param name="cfgcookie" value="' + stCfgCookie + '"><param name="invokedByCode" value="' + GetInvokedByCode() +'"><param name="pkgver" value="' + packageVersion + '"><param name="aggauth" value="' + stAggAuth + '"><param name="configurationuri" value="' + stConfigurationURI + '"><param name="launchtype" value="' + stLaunchType + '"></applet>';
				document.getElementById( "idDivMain" ).innerHTML = stContent;
			}
			timeWaitStart = new Date();
			iStatus = 41;
		}
		break;
	case 22:
            // ActiveX failed, and we have no java :(
            iStatus = -70;
            //Update User Alert
            setAlert(3,'Automatic Provisioning was unsuccessful.');
            break;
	case 41:
            try
            {
                var timeWaitNow = new Date();
                if ( timeWaitNow.getTime() - timeWaitStart.getTime() > 60000 )
                {
                    iStatus = 22;
                }
                else
                {
                    if ( IsIE )
                    {
                        if(!isAppletRunning)
                        {
                            if(GetCookie(appletCookieName) == appletCookieValue)
                            {
                                    isAppletRunning = true;
                            }
                        }
                        else
                        {
                            if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_STARTED )
                                   iStatus = 42;
                           else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_IN_PROGRESS )
                                   iStatus = 43;
                           else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_SUCCESS )
                                   iStatus = -100;
                           else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_FAILURE )
                                   iStatus = 44;
                           else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_CONNECTION_FAILURE )
                                   iStatus = -80;
                           else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_REBOOT_REQUIRED )
                                   iStatus = -81;
                           else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_WEBLAUNCH_RESTRICTED)
                                   iStatus = -90;
                           else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_ALLOW_UNTRUSTED_CERT_RETRY)
                                   iStatus = -91;
                           else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_GUI_LAUNCH_FAILED)
                                   iStatus = -92;
                           else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_NON_PRIVELEGED_SECOND_INSTANCE)
                                   iStatus = -93;
                           else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_AC_CORE_UPDATES_FROM_ISE_OVER_VPN_TUNNEL)
                                   iStatus = -94;
                           else if (document.frames["idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_KEEP_ME_SAFE_UNTRUSTED_CERT)
                                   iStatus = -95;
                           else if (document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_VERIFY_CERT_PIN_CHECK_FAILED)
                                   iStatus = -96;
                           //Delete Cookie once we know that the applet has 'started'
                           DeleteCookie (appletCookieName);
                        }
                    }
                    else
                    {
                        // check for applet being loaded
                        if ( document.applets['idJavaSun'] )
                                iStatus = 42;
                        else
                                iStatus = 44;
                    }
                }
            }
            catch(e)
            {
                    var timeWaitNow = new Date();
                    if ( timeWaitNow.getTime() - timeWaitStart.getTime() > 20000 )
                            iStatus = 22;
            }
		break;
    case 42:
        if ( IsIE )
        {
            if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_FAILURE )
                iStatus = 44;
            else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_IN_PROGRESS )
                iStatus = 43;
            else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_SUCCESS )
                iStatus = -100;
            else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_CONNECTION_FAILURE )
                iStatus = -80;
            else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_REBOOT_REQUIRED )
                iStatus = -81;
            else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_WEBLAUNCH_RESTRICTED)
                iStatus = -90;
            else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_ALLOW_UNTRUSTED_CERT_RETRY)
                iStatus = -91;
            else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_GUI_LAUNCH_FAILED)
                iStatus = -92;
            else if (document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_NON_PRIVELEGED_SECOND_INSTANCE)
                iStatus = -93;
            else if (document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_AC_CORE_UPDATES_FROM_ISE_OVER_VPN_TUNNEL)
                iStatus = -94;
            else if (document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_KEEP_ME_SAFE_UNTRUSTED_CERT)
                iStatus = -95;
            else if (document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_VERIFY_CERT_PIN_CHECK_FAILED)
                iStatus = -96;
        }
        else
        {
            if ( document.applets['idJavaSun'].status == str_STATUS_DL_FAILURE )
                iStatus = 44;
            else if ( document.applets['idJavaSun'].status == str_STATUS_DL_IN_PROGRESS )
                iStatus = 43;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_SUCCESS)
                iStatus = -100;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_CONNECTION_FAILURE)
                iStatus = -80;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_REBOOT_REQUIRED)
                iStatus = -81;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_WEBLAUNCH_RESTRICTED)
                iStatus = -90;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_ALLOW_UNTRUSTED_CERT_RETRY)
                iStatus = -91;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_GUI_LAUNCH_FAILED)
                iStatus = -92;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_NON_PRIVELEGED_SECOND_INSTANCE)
                iStatus = -93;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_AC_CORE_UPDATES_FROM_ISE_OVER_VPN_TUNNEL)
                iStatus = -94;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_KEEP_ME_SAFE_UNTRUSTED_CERT)
                iStatus = -95;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_VERIFY_CERT_PIN_CHECK_FAILED)
                iStatus = -96;
            else if ( String(document.applets['idJavaSun'].status) == 'undefined')
            {
                // will get here if JVM detects a cert validation problem
                // and pops up a dialog asking the user if they want to
                // continue - give them 60 seconds to respond then bail out.
                // Upon timeout, the web page will indicate a failure.  If
                // the security pop-up is still open and then the user allows
                // the Java to run, the Downloader will still run.  If the
                // install and tunnel succeed then there may be some confusion
                // since the web page displays a failure message but the
                // install weas successful and the tunnel is up.  The solution
                // is for the head-end admin to get a real cert!
                var timeWaitNow = new Date();
                if ( timeWaitNow.getTime() - timeWaitStart.getTime() > 60000 )
                    iStatus = 44;
            }
        }
        break;
    case 43:
        if ( IsIE )
        {
            if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_FAILURE )
                iStatus = 44;
            else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_SUCCESS )
                iStatus = -100;
            else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_CONNECTION_FAILURE )
                iStatus = -80;
            else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_REBOOT_REQUIRED )
                iStatus = -81;
            else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_WEBLAUNCH_RESTRICTED)
                iStatus = -90;
            else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_ALLOW_UNTRUSTED_CERT_RETRY)
                iStatus = -91;
            else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_GUI_LAUNCH_FAILED)
                iStatus = -92;
            else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_NON_PRIVELEGED_SECOND_INSTANCE)
                iStatus = -93;
            else if ( document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_AC_CORE_UPDATES_FROM_ISE_OVER_VPN_TUNNEL)
                iStatus = -94;
            else if (document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_KEEP_ME_SAFE_UNTRUSTED_CERT)
                iStatus = -95;
            else if (document.frames[ "idiFrameMain" ].document.idJavaSun.status == str_STATUS_DL_VERIFY_CERT_PIN_CHECK_FAILED)
                iStatus = -96;
        }
        else
        {
            if (document.applets['idJavaSun'].status == str_STATUS_DL_FAILURE)
                iStatus = 44;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_SUCCESS)
                iStatus = -100;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_CONNECTION_FAILURE)
                iStatus = -80;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_REBOOT_REQUIRED)
                iStatus = -81;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_WEBLAUNCH_RESTRICTED)
                iStatus = -90;
            else if ( String(document.applets['idJavaSun'].status) == 'undefined')
                iStatus = 44;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_ALLOW_UNTRUSTED_CERT_RETRY)
                iStatus = -91;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_GUI_LAUNCH_FAILED)
                iStatus = -92;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_NON_PRIVELEGED_SECOND_INSTANCE)
                iStatus = -93;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_AC_CORE_UPDATES_FROM_ISE_OVER_VPN_TUNNEL)
                iStatus = -94;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_KEEP_ME_SAFE_UNTRUSTED_CERT)
                iStatus = -95;
            else if (document.applets['idJavaSun'].status == str_STATUS_DL_VERIFY_CERT_PIN_CHECK_FAILED)
                iStatus = -96;
        }
        break;
    case 44:
        // Java failed
        iStatus = -70;
        //Update User Alert
        setAlert(3,'Web-based installation was unsuccessful.');

        break;
    case -60:
        // Could not launch with this package -- try the next package
        bLoop = false;
        var new_path = window.location.href;
        var pos = new_path.indexOf( "/stc/" ) + 5;
        if ( pos !== 4 )
        {
            var current = new_path.charAt(pos);
            current++;
            new_path = new_path.substring(0,pos) + current + new_path.substring(pos+1);
            window.location.href = new_path;
        }
        break;
    case -70:
        showManualDownload();
        bLoop = false;
        break;
    case -71:
        showAutoProvisioningDownload();
        bLoop = false;
        break;
    case -80:
    case -81:
        update_status_alert(3,iStatus);
        GetElement("idDivMessage").innerHTML += '<br><br>Please <a href="javascript:document.location.reload()">retry the connection</a> if you wish to continue.';
        bLoop = false;
        break;
    case -90:
        iStatus = -70;
        showManualDownload();
        bLoop = false;
        break;
    case -91:
        showUntrustedCertRetry();
        bLoop = false;
        break;
    case -92:
        setAlert(3,"Failed to launch " + clientName);
        updateMessage();
        bLoop = false;
        break;
    case -93:
        setAlert(3,clientName + "downloader is already running.");
        updateMessage();
        bLoop = false;
        break;
    case -94:
        setAlert(3,"Updates are required.");
        updateMessage();
        bLoop = false;
        break;
    case -95:
    case -96:
        setAlert(3,"Untrusted servers dectected.");
        updateMessage();
        bLoop = false;
        break;
    case -100:
        var statusMsgTitle = "Connection Established";
	    setAlert(2,statusMsgTitle);
        var msg = "<br><br>" + packageConnectMsg + "<br>";

        document.getElementById( "idDivMessage" ).innerHTML += msg;

        bLoop = false;
        break;
    }
    if ( bLoop )
    {
        setTimeout( 'Launch();', 500 );
    }
}

//-----------------------------------------------------------------
//This method toggles visiblity of a div
//-----------------------------------------------------------------
function toggle_div_visibility(id) {

   var x = document.getElementById(id);
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}

//-----------------------------------------------------------------
//This method gets the Microsoft IE version. If browser is not 
//IE flavor ruturns false.
//-----------------------------------------------------------------
function msieversion() {

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv:11\./))  // If Internet Explorer, return version number
    {
        //alert(parseInt(ua.substring(msie + 5, ua.indexOf(".", msie))));
    }
    else  // If another browser, return 0
    {
        //alert('otherbrowser');
    }

    return false;
}

//-----------------------------------------------------------------
//Checks to see if ActiveX is available in browser
//-----------------------------------------------------------------
function ActiveXDefined() {
    return typeof (window.ActiveXObject) !== "undefined";
}
//-----------------------------------------------------------------
//Returns true if Active X is enabled false otherwise
//-----------------------------------------------------------------
function isActiveXEnabled()
{
    var isIE = msieversion();
    var isActiveXEnabled = ActiveXDefined();
    
    return !!(isIE && isActiveXEnabled);
    

}

//-----------------------------------------------------------------
//Returns true if Java is enabled false otherwise
//-----------------------------------------------------------------
function isJavaEnabled()
{
    return navigator.javaEnabled();    
}

//-----------------------------------------------------------------
//Checks for Empty String.  
//Returns true if str is empty,blank, null or undefined. 
//-----------------------------------------------------------------
function empty(str)
{
    return typeof str == 'undefined' || !str || str.length === 0 || str === "" || !/[^\s]/.test(str) || /^\s*$/.test(str) || str.replace(/\s/g, "") === "";
}

//-----------------------------------------------------------------
//Opens the Tip/Help Windows
//-----------------------------------------------------------------
function openTipsWindow() {

    var helpfile = "tips.htm";
   
    window.open(helpfile, 'tips',
      'width=' + 975 + ',height='+ screen.height + ',scrollbars=yes,toolbar=no,directories=no,' +
        'status=no,menubar=no,top=0,screenY=0,resizable,' );

}

//-----------------------------------------------------------------
//Closes Tips/Help Window
//-----------------------------------------------------------------
function closeopenTipsWindow() {
    window.close();   // Closes the new window
}

function showManualDownload()
{
    //Set Action Panel Header text
    document.getElementById("provisioning_action_label").textContent="Download & Install";
    
    //Set Manual Install instructions
    showInstallInstructions("manual");

    //Since Edge does not support any NPAPI based plugins 
    //Do not add the option to provide weblaunch on this browser
    if(isJAVAorActiveXSupported() )
    {
        //Allow the user to select Manual or Automatic provisioning 
        document.getElementById("ac_multiple_download_option_tabs").style.display = 'block';

        //Sets the appropriate controls "active" class.
        toggle_prov_tab("ac_tab_man_prov","ac_tab_auto_prov");
    }

    //Adds this alternative text to action panel text.
    GetElement("idDivMessage").innerHTML += '<div class="panel panel--loose panel--ltgray text-center"><div class="section"><button id="manualInstallButton" type="button" value="Download" class="btn btn--primary" onclick="downloadACPackage();">Download</button></div></div>';
    
    //Set action text to appropriate item.
    var platformTxt = "";
    if(IsMac)
    {
        platformTxt = "macOS";
    }else if(IsWinNT) {
        platformTxt = "Windows"; 
    }else if(IsLinux || IsLinux64) {
        platformTxt = "Linux";
    }else {
        platformTxt = "";
    }
    //Set Download button with Platform information (ie "Download for Mac")
    setDownloadButtonTxt("Download for " + platformTxt);
}


function showAutoProvisioningDownload()
{
       //Clear out main idDivMessage Containts
    document.getElementById("idDivMessage").innerHTML = "";
    
    //Set Auto Install instructions
    showInstallInstructions("auto");
    
     //Adds this alternative text to action panel text.
    GetElement("idDivMessage").innerHTML += '<div>Click launch to begin ' + clientName + ' software provisioning.<div class="panel panel--loose panel--ltgray text-center"><div class="section"><button id="autoInstallButton" type="button" value="Launch" class="btn btn--primary" onclick="beginAutoProvisioningDownload();" >Launch</button></div><SMALL><EM>Note:  Some browsers may have Java & Active-X plugins disabled by default.<BR>You may need to configure your browser to enable these before proceeding.</EM></SMALL></div></div>';

    //Set action text to appropriate item.
    var platformTxt = "";
    if(IsMac)
    {
        platformTxt = "macOS"; 
    }else if(IsWinNT) {
        platformTxt = "Windows"; 
    }else if(IsLinux || IsLinux64) {
        platformTxt = "Linux";
    }else {
        platformTxt = "";
    }

    //Set Download button with Platform information (ie "Launch for Mac")
    document.getElementById("autoInstallButton").textContent = "Launch for " + platformTxt;
    
}

//-----------------------------------------------------------------
//Launch Manual Download
//-----------------------------------------------------------------
function beginAutoProvisioningDownload() {
    
    //Clear any Potential Alerts
    setAlert(0,' ');
    
    document.getElementById("idDivMessage").innerHTML = "";
  
    loadPackage();
    
    //Set the appropriate State for automatic Java/Active launch
    Start(1);
    
    //Toggle open action div
    document.getElementById("action_panel").style.display = 'block';
}

//-----------------------------------------------------------------
//Sets Download Button Text Contents
//-----------------------------------------------------------------
function setDownloadButtonTxt(buttonTxt) {
  
  var ButtonText = "Download";
  
    if(!empty(buttonTxt))
    {
        ButtonText = buttonTxt;
        
    }
    //Sets Download button text
    document.getElementById("manualInstallButton").textContent = ButtonText;   
}

//-----------------------------------------------------------------
// This configures wheather the auto install instructions are enabled
// or the manual install instructions.
//-----------------------------------------------------------------
function showInstallInstructions(mode) {

    //Sets appropriate instruction visiblity
    switch ( mode )
    {
        case 'auto':
            document.getElementById("manual_install_instructions").style.display = 'none';
            document.getElementById("auto_install_instructions").style.display = 'block';
            break;
        case 'manual':
            document.getElementById("manual_install_instructions").style.display = 'block';
            document.getElementById("auto_install_instructions").style.display = 'none';
            break;
        case 'none':
            document.getElementById("manual_install_instructions").style.display = 'none';
            document.getElementById("auto_install_instructions").style.display = 'none';
            break;
    }
}

//-----------------------------------------------------------------
// This method loads the user Install instructions into there
// corresponding divs in the page.
//-----------------------------------------------------------------
function loadInstructionPages(){

    $.get('manual-instructions.html', function(data) {
        $('#manual_install_instructions').html(data);
    });

    $.get('auto-instructions.html', function(data) {
        $('#auto_install_instructions').html(data);
    });
}

//-----------------------------------------------------------------
// This method loads the webpage icons/images
//-----------------------------------------------------------------
function loadIcons() {

    //cisco logo
    var cui_cisco_logo = document.getElementById("cui_cisco_logo");
    var edge_cisco_logo = document.getElementById("edge_cisco_logo");

    //help icon
    var cui_cisco_help_icon = document.getElementById("cui_cisco_help_icon");
    var edge_cisco_help_icon = document.getElementById("edge_cisco_help_icon");

    //info icon
    var cui_cisco_info_icon = document.getElementById("cui_cisco_info_icon");
    var edge_cisco_info_icon = document.getElementById("edge_cisco_info_icon");

    var cui_cisco_success_icon = document.getElementById("cui_cisco_success_icon");
    var edge_cisco_success_icon = document.getElementById("edge_cisco_success_icon");

    var cui_cisco_warn_icon = document.getElementById("cui_cisco_warn_icon");
    var edge_cisco_warn_icon = document.getElementById("edge_cisco_warn_icon");

    var cui_cisco_error_icon = document.getElementById("cui_cisco_error_icon");
    var edge_cisco_error_icon = document.getElementById("edge_cisco_error_icon");

    var ac_expand_collapse_icons = document.getElementById("ac_expand_collapse_icons");

    /*
    In order to display icons appropriately on the Edge & IE browser it was necessary
    to replace the CUIs framework font icons with our own.  Once the CUIs team
    addresses this issue we can remove this handling.
     */

    if( IsIEorEDGE )
    {
        cui_cisco_logo.style.display = "none";
        edge_cisco_logo.style.display = "block";

        cui_cisco_help_icon.style.display = "none";
        edge_cisco_help_icon.style.display = "block";

        cui_cisco_info_icon.style.display  = "none";
        edge_cisco_info_icon.style.display = "float";

        cui_cisco_success_icon.style.display  = "none";
        edge_cisco_success_icon.style.display = "float";

        cui_cisco_warn_icon.style.display  = "none";
        edge_cisco_warn_icon.style.display = "float";

        cui_cisco_error_icon.style.display  = "none";
        edge_cisco_error_icon.style.display = "float";

        ac_expand_collapse_icons.style.display = "none";

    }else {
        cui_cisco_logo.style.display = "block";
        edge_cisco_logo.style.display = "none";

        cui_cisco_help_icon.style.display = "block";
        edge_cisco_help_icon.style.display = "none";

        cui_cisco_info_icon.style.display  = "float";
        edge_cisco_info_icon.style.display = "none";

        cui_cisco_success_icon.style.display  = "float";
        edge_cisco_success_icon.style.display = "none";

        cui_cisco_warn_icon.style.display  = "float";
        edge_cisco_warn_icon.style.display = "none";

        cui_cisco_error_icon.style.display  = "float";
        edge_cisco_error_icon.style.display = "none";

        ac_expand_collapse_icons.style.display = "block";
    }

}

function downloadACPackage() {
    //Dismiss any Alert Showing
    setAlert(0,' ');
    
    var InstallerPackage = "binaries/" + packageInstaller;
    
    window.open(InstallerPackage);
}

//-----------------------------------------------------------------
// This Method will set/show alerts to user
// alert_type   = 0 = Clear Alerts
//              = 1 = informational 
//              = 2 = success
//              = 3 = warning
//              = 4 = danger
//              
//-----------------------------------------------------------------
function setAlert(ac_alert_type,ac_message) {

    var info_alert_item, success_alert_item, warning_alert_item, danger_alert_item, buffer, final_alert_message;
    info_alert_item = document.getElementById("ac_info_alert");
    success_alert_item = document.getElementById("ac_success_alert");
    warning_alert_item  = document.getElementById("ac_warning_alert");
    danger_alert_item   = document.getElementById("ac_danger_alert");
    
    buffer = '\t';
    
    //Sets appropriate alert type visiblity
    switch ( ac_alert_type )
    {
        case 0:
        {
            //Info Alert
            final_alert_message = ' '; 
            info_alert_item.style.display = 'none';
            success_alert_item.style.display = 'none';
            warning_alert_item.style.display = 'none';
            danger_alert_item.style.display = 'none';
        }
        break;
	case 1:
        {
            //Info Alert
            final_alert_message = 'Information:' + buffer + ac_message;
            info_alert_item.style.display = 'block';
            success_alert_item.style.display = 'none';
            warning_alert_item.style.display = 'none';
            danger_alert_item.style.display = 'none';
        }
        break;
	case 2:
        {
            //Success Alert
            final_alert_message = 'Success: ' + buffer + ac_message;
            info_alert_item.style.display = 'none';
            success_alert_item.style.display = 'block';
            warning_alert_item.style.display = 'none';
            danger_alert_item.style.display = 'none';

        }
        break;
    	case 3:
        {
            //Warning Alert
            final_alert_message = 'Warning: ' + buffer + ac_message;
            info_alert_item.style.display = 'none';
            success_alert_item.style.display = 'none';
            warning_alert_item.style.display = 'block';
            danger_alert_item.style.display = 'none';
        }
        break;
        case 4:
        {
            //Danger Alert
            final_alert_message = 'Error: ' + buffer + ac_message;            
            info_alert_item.style.display = 'none';
            success_alert_item.style.display = 'none';
            warning_alert_item.style.display = 'none';
            danger_alert_item.style.display = 'block';
        }
        break;
    }
    
    //Set the Alert Text
    $('.alert__message').html(final_alert_message);
}

//-----------------------------------------------------------------
// This method takes a alert type and a string id to show alert to
// the user.
//-----------------------------------------------------------------
function update_status_alert(alert_type, iStringID){
    //calls function to 
    setAlert(alert_type,aszMessage[language][ Math.abs( iStringID ) ]);
}

//-----------------------------------------------------------------
// This handler is called when manual download tab option is 
// clicked by the user.  It toggles the active option as well as sets
// the status step to the appropriate manual step to download.
//-----------------------------------------------------------------
function manual_prov_tab_clicked(){

    //Clear any Potential Alerts
    setAlert(0,' ');

    //Sets the appropriate controls "active" class.
    toggle_prov_tab("ac_tab_man_prov","ac_tab_auto_prov"); 
    
    //Skips to Manual Install Steps
    skipToManualInstall();
}

//-----------------------------------------------------------------
// This handler is called when user clicks the automatic provisioning
// option.  It toggles the active tab option as well as sets
// the status step to the appropriate manual step to download.
//-----------------------------------------------------------------
function auto_prov_tab_clicked(){

    //Clear any Potential Alerts
    setAlert(0,' ');

    //Sets the appropriate controls "active" class.
    toggle_prov_tab("ac_tab_auto_prov","ac_tab_man_prov"); 
    
    showAutoProvisioningDownload();
}

//-----------------------------------------------------------------
// This method toggles provisioning tab.
// active_tab_id = The id of the item you want to activate
// deactive_tab_id = The id of the item you want to deactivate
//-----------------------------------------------------------------
function toggle_prov_tab(active_tab_id,deactivate_tab_id)
{
    var activateThisElement = document.getElementById(active_tab_id);
    var deactivateThisElement = document.getElementById(deactivate_tab_id);
    
    //Sets the appropriate controls "active" class.
    addClass(activateThisElement,"active");
    // if visible is set remove it, otherwise add it
    removeClass(deactivateThisElement,"active");
}

//-----------------------------------------------------------------
// This method allows user to cancel ActiveX processing and skip to 
// Java attempt for weblaunch.
//-----------------------------------------------------------------
function cancelActiveX()
{
    Start(20);
}

//-----------------------------------------------------------------
// This method toggles the instruction div.
//-----------------------------------------------------------------
function toggle_install_instructions() {
    var ele         = document.getElementById("toggleInstructions");
    var infoopen    = document.getElementById("infoopen");
    var infoclosed  = document.getElementById("infoclosed");

    if(ele.style.display == "block") {
        ele.style.display = "none";

        infoopen.style.display = "none";
        infoclosed.style.display = "block";

    } else {
        ele.style.display = "block";
        infoopen.style.display = "block";
        infoclosed.style.display = "none";
    }
}

//-----------------------------------------------------------------
//-----------------------------------------------------------------
//-----------------------------------------------------------------
//-----------------------------------------------------------------
//-----------------------------------------------------------------
//                  END OF MAIN.JS 
//-----------------------------------------------------------------
//-----------------------------------------------------------------
//-----------------------------------------------------------------
//-----------------------------------------------------------------
//-----------------------------------------------------------------