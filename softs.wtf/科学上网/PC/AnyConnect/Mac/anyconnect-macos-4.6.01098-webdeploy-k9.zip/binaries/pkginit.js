/**************************************************************************
*       Copyright (c) 2017, Cisco Systems, All Rights Reserved
***************************************************************************
*
*  File:    pkgint.js
*
***************************************************************************
*
* Mac OS X init file for AnyConnect Secure Mobility Client WebLaunch.
*
***************************************************************************/

var supportedCpu = "X86";
var packageConnectImg = new Image(290, 80);
packageConnectImg.src = "img/osx-statusbar.png";

var packageConnectMsg;

function loadPackage ()
{

    packageConnectMsg = 'The connection can be controlled from the icon in your menu bar.<br><br><img src="' 
			+ packageConnectImg.src + '" width ="' + packageConnectImg.width + '" height="' + packageConnectImg.height + '"><br>';
 
    if (IsIntelMacOsX)
    {
        // Magic state 0 == Wait for User to initiate Download option.
        Start(0);
    }
    else
    {
        // Magic state -60 == go to the next installed package
        Start(-60);
    }
}
var packageInstaller = "anyconnect-macos-4.6.01098-core-vpn-webdeploy-k9.dmg";
var packageVersion = "4,6,01098";
